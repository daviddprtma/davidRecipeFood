
var routes = [
  {
    path: '/index',
    url: './index.html',
  },
  {
    path:'/login',
    url:'./login.html',
  },
  {
    path: '/recipe',
    url: './recipe.html',
  },
  {
    path:'/detailrecipe/:id',
    url:'./detailrecipe.html',
    options:{
      transition: 'f7-flip'
    }
  },
  {
    path: '/caridata',
    url: './caridata.html',
  },
  {
    path:'/detailrecipe2/:id',
    url:'./detailrecipe2.html',
  },
  {
    path: '/tambahdata',
    url: './tambahdata.html',
  },
  {
    path: '/favorituser',
    url: './favorituser.html',
  },
  
];
