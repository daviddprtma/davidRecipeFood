var $ = Dom7;

var recipe = [];
recipe.push({judul:'Hamburger', 
bahan:'Sekitar 500 g daging sapi giling,6 bun burger,1 kuning telur,½ bawang bombay Saus tomat 1 sendok makan saus Worcestershire 1 sendok makan mustard 1 sendok makan lada putih 1 siung bawang putih Sedikit daun bumbu segar, iris kasar Lada dan garam untuk memberi rasa ',
persiapan:'Pilih daging yang tepat, Letakkan daging sapi giling di dalam mangkuk,Cincang kasar bawang bombay dan bawang putih,Tambahkan bahan lain yang ingin Anda tambahkan ke dalam burger,Tambahkan telur kuning.Buat burger.',
gambar: 'https://www.wikihow.com/images/thumb/4/45/Make-a-Hamburger-Step-16-Version-2.jpg/v4-728px-Make-a-Hamburger-Step-16-Version-2.jpg.webp'});

recipe.push({judul:'Sop Daging Sapi', 
bahan:'300 g daging sapi, potong kotak 2 buah kentang ukurang sedang, potong kotak 2 buah wortel, potong 22 batang daun bawang, potong 1 ccm daun seledri garam merica 1L air 4 sdm Bango Kecap Manis minyak untuk menumis',
persiapan:'Rebus daging hingga empuk. Sementara tumis bumbu halus hingga harum. Kemudian masukkan bumbu halus ke dalam rebusan daging Masukkan kentang, setelah kentang setengah matang, masukkan wortel dan buncis serta Bango Kecap Manis. Tambahkan daun bawang seledri, garam dan merica bubuk. Sajikan.',
gambar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQn5axQuTk0dDrVLbdrjwCcFAJJ5Rg7E3_yvA&usqp=CAU'});

recipe.push({judul:'Tumis Buncis Telur', 
bahan:'250g buncis, siangi dan iris serong 2 butir telur ayam, kocok lepas 3 butir bawang merah, iris tipis 2 siung bawang putih, iris tipis 3 buah cabai merah besar, buang biji dan iris tipis 100 ml air 2 sdt Royco Kaldu Ayam 1 sdm Bango Kecap Manis Light ¼ sdt merica putih bubuk minyak sayur',
persiapan:'Tumis bawang merah, bawang putih, dan cabai merah besar sampai harum. Masukkan telur, masak orak arik. Tambahkan buncis, air dan tumis hingga setengah layu.Tuangkan Bango Kecap Manis Light, Royco Kaldu Ayam, dan merica. Aduk rata. Setelah matang, angkat dan sajikan.',
gambar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlrEhmvNcPZ1N3aiZJsQhboMHdB_lKECg9Vg&usqp=CAU'});

recipe.push({judul:'Pizza ', 
bahan:'250 gr Tepung terigu 6 gr Ragi 2 sdm gula pasir 150 ml air hangat yang dilarutkan dgn 1 sachet susu dancow 5 sdm minyak 1/2 sdm garam Sosis beef burger paprika bawang bombay jagung manis Saus spagethi lafonte / del monte Keju blueband untuk olesan loyang',
persiapan:'Campur ragi, gula pasir ke dalam susu hangat. kemudian aduk diamkan kurang lebih 3menit hingga berbusa (tanda ragi aktif) Campur kan garam ke dalam terigu, lalu masukan susu.. di aduk rata lalu uleni sebentar. kemudian masukan minyak sayur uleni hingga adonan kalis. diamkan kurang lebih 45menit hingga mengembang Setelah adonan mengembang bagi 2 atau bagi sesuai dg ukuran loyang yg ada.. olesi loyang dgn blueband baru adonan pizza di pipih pipih kan secara rata.. beri saus lafonte, dan toping kemudian keju. oiya sambil menata toping, panaskan oven kurang lebih 15menit suhu 200derajat, api atas bawah Panggang pizza selama 20menit dengan api atas bawah... selamat mencoba.. ',
gambar: 'https://img-global.cpcdn.com/recipes/9b2293a04b1dff84/1360x964cq70/pizza-rumahan-sederhana-foto-resep-utama.webp'});


var device = Framework7.getDevice();
var app = new Framework7({
  name: '160419103_FoodRecipes', // App name
  theme: 'auto', // Automatic theme detection
  el: '#app', // App root element

  id: 'io.framework7.myapp', // App bundle ID
  // App store
  store: store,
  // App routes
  routes: routes,


  // Input settings
  input: {
    scrollIntoViewOnFocus: device.cordova && !device.electron,
    scrollIntoViewCentered: device.cordova && !device.electron,
  },
  // Cordova Statusbar settings
  statusbar: {
    iosOverlaysWebView: true,
    androidOverlaysWebView: false,
  },
  on: {
    init: function () {
      var f7 = this;
      if (f7.device.cordova) {
        // Init cordova APIs (see cordova-app.js)
        cordovaApp.init(f7);
      }
      $(document).on('page:afterin', function (e, page) {       
                if(!localStorage.username) { 
                    if(page.name != 'login'){
                      page.router.navigate('/login/');
                    }
                }
      });

      $(document).on('page:init',function(e,page){
        
        if(page.name== 'login'){
          //untuk meremove username
          localStorage.removeItem("username");

          $('#btnsignin').on('click',function(){
            app.request.post("http://ubaya.fun/hybrid/160419103/login.php", 
            {"username":$('#username').val(), "password":$('#password').val()},
            function(data){
              var arr = JSON.parse(data);
              var result = arr['result'];
              if(result=='success'){
                localStorage.username = $('#username').val();
                page.router.back('/');
              }
              else{
                app.dialog.alert("Username / password salah");
              }
            });
          });
        }
        else if(page.name== 'recipe'){
          recipe.forEach( (t,index) => {
            $("#recipefood").append(
              "<div class='card'>"+
                              "<div class='card-header'>"+
                              t.judul +
                              "</div><div class='card-content'>"+
                              "<img src='"+ t.gambar + "' width='100%'>"+
                              "<div class='card-footer'> <a href='/detailrecipe/" + index + "'>Read More</a></div></div></div>");     
          });
        }
        else if(page.name=='detailrecipe'){
          var id = page.router.currentRoute.params.id;

          $('#detailfood').html(
            "<div class='card'>"+
            "<div class='card-header'>"+
            recipe[id].judul +
            "</div><div class='card-content'>"+
            "<img src='"+ recipe[id].gambar + "' width='100%'>"+
            "<br><div class='block'><p>"+
           "Bahan: " + recipe[id].bahan + 
           "<br>" + 
           "Persiapan: " + recipe[id].persiapan + 
            "</p></div></div>"
          );
        }
        else if(page.name=='caridata'){
          var url = "http://ubaya.fun/hybrid/160419103/listrecipe.php";

          app.request.post(url,{},function(data)
            {
              var arr = JSON.parse(data); 
              recipe=arr['data'];
              $('#ul_listrecipe').html("");
              for(var i=0; i < recipe.length; i++) {
              $("#ul_listrecipe").append("<li><a href='/detailrecipe2/'>"
                                        +recipe[i]["judul"] + '</a></li>');
              }
            }
            );

            $('#btncari').on('click',function() {
              var c = $('#txtcari').val();
              app.request.post(url, {judul:c}, function(data){
                var json = JSON.parse(data); 
                recipe=json['data'];
                $('#ul_listrecipe').html("");
                for(var i=0; i < recipe.length; i++) {
                  $("#ul_listrecipe").append("<li><a href='#'>" + recipe[i]["judul"] + '</a></li>');
                }
              });
            });
        }
        else if(page.name=='detailrecipe2'){
          var id = page.router.currentRoute.params.id;
          var url ="http://ubaya.fun/hybrid/160419103/displayrecipe.php";
          app.request.post(url,{"id":id},function(data)
            {
              var food = JSON.parse(data);
              recipe = food['data'];
              $('#judul').html(recipe[0]["judul"]);
              $('#bahan').html(recipe[0]["bahan"]);
              $('#persiapan').html(recipe[0]["persiapan"]);

              categoryname=recipe['categoryname'];

              for(var i=0; i< categoryname.length; i++) {
                $('#foodcategory').append('<li>' + categoryname[i]['categoryname'] + '</li>');
              }
            }
          );
        }
        else if(page.name=='tambahdata'){
          $('#buttonsubmit').on('click',function(){
            var judul = $('#tx_judul').val();
            var bahan = $('#tx_bahan').val();
            var persiapan = $('#tx_persiapan').val();
            var gambar = $('#tx_gambar').val();

            app.request.post("http://ubaya.fun/hybrid/160419103/addrecipefood.php",
            {'judul':judul, 'bahan':bahan , 'persiapan':persiapan, 'gambar':gambar},function(data){
              var arr = JSON.parse(data);
              var result = arr['result'];
              if(result == 'success'){
                app.dialog.alert("Sukses menambah data recipe food :) :D ");
                app.view.main.router.navigate('/index.html',{
                    reloadCurrent: true,
                    pushState: false // biar tidak bisa kembali ke awal 
                });
              }
              else{
                app.dialog.alert("Gagal menambah data recipe");
              }
            });
          });
        }
      })
    },
  },
});
