console.log('\u001b[35m\u001b[1m','Love Framework7? Support Vladimir\'s work by donating or pledging:');
console.log('\u001b[22m\u001b[39m\u001b[32m','> On Patreon https://patreon.com/framework7');
console.log('\u001b[22m\u001b[39m\u001b[32m','> On Open Collective http://opencollective.com/framework7');
